package com.example.weather1

data class Rain(
    val `1h`: Double
)