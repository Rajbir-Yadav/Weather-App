package com.example.weather1

data class Clouds(
    val all: Int
)