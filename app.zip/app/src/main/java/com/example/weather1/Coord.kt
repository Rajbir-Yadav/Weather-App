package com.example.weather1

data class Coord(
    val lat: Double,
    val lon: Double
)