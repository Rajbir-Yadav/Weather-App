package com.example.weather1

data class Sys(
    val country: String,
    val sunrise: Int,
    val sunset: Int
)