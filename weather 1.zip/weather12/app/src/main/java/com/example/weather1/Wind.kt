package com.example.weather1

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)